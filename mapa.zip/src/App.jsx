import CareerMindMap from './components/CareerMindMap';
import './index.css';

function App() {
  return (
    <div className="App">
      <CareerMindMap />
    </div>
  );
}

export default App;