// src/data/positions.js

export const positions = {
  'dev-net': {
    id: 'dev-net',
    title: 'Desenvolvedor .NET',
    level: 'Pleno',
    salary: 'R$ 8.000 - R$ 12.000',
    salaryMin: 8000,
    salaryMax: 12000,
    color: '#1E3A8A',
    connections: ['dev-senior', 'analista-sistemas'],
    pillar: 'Tecnologia',
    description: 'Desenvolvimento de aplicações web e desktop utilizando tecnologias Microsoft .NET.'
  },
  'analista-sistemas': {
    id: 'analista-sistemas',
    title: 'Analista de Sistemas',
    level: 'Pleno',
    salary: 'R$ 9.000 - R$ 13.000',
    salaryMin: 9000,
    salaryMax: 13000,
    color: '#1E40AF',
    connections: ['arquiteto-sistemas', 'coordenador-ti'],
    pillar: 'Tecnologia',
    description: 'Análise, desenvolvimento e manutenção de sistemas corporativos.'
  },
  'dev-senior': {
    id: 'dev-senior',
    title: 'Desenvolvedor Sênior',
    level: 'Sênior',
    salary: 'R$ 12.000 - R$ 18.000',
    salaryMin: 12000,
    salaryMax: 18000,
    color: '#2563EB',
    connections: ['tech-lead', 'arquiteto-software'],
    pillar: 'Tecnologia',
    description: 'Desenvolvimento de soluções complexas e liderança técnica de projetos.'
  },
  'arquiteto-software': {
    id: 'arquiteto-software',
    title: 'Arquiteto de Software',
    level: 'Sênior',
    salary: 'R$ 15.000 - R$ 25.000',
    salaryMin: 15000,
    salaryMax: 25000,
    color: '#3B82F6',
    connections: [],
    pillar: 'Tecnologia',
    description: 'Definição da arquitetura técnica e padrões de desenvolvimento.'
  },
  'tech-lead': {
    id: 'tech-lead',
    title: 'Tech Lead',
    level: 'Sênior',
    salary: 'R$ 14.000 - R$ 20.000',
    salaryMin: 14000,
    salaryMax: 20000,
    color: '#60A5FA',
    connections: ['coordenador-ti'],
    pillar: 'Tecnologia',
    description: 'Liderança técnica de equipes e coordenação de projetos de desenvolvimento.'
  },
  'coordenador-ti': {
    id: 'coordenador-ti',
    title: 'Coordenador de TI',
    level: 'Coordenação',
    salary: 'R$ 12.000 - R$ 18.000',
    salaryMin: 12000,
    salaryMax: 18000,
    color: '#93C5FD',
    connections: [],
    pillar: 'Gestão',
    description: 'Coordenação de equipes de TI e gestão de projetos tecnológicos.'
  },
  'arquiteto-sistemas': {
    id: 'arquiteto-sistemas',
    title: 'Arquiteto de Sistemas',
    level: 'Especialista',
    salary: 'R$ 18.000 - R$ 28.000',
    salaryMin: 18000,
    salaryMax: 28000,
    color: '#BFDBFE',
    connections: [],
    pillar: 'Tecnologia',
    description: 'Arquitetura de sistemas empresariais e integração de plataformas.'
  },
  // ÁREA FINANCEIRA
  'analista-financeiro': {
    id: 'analista-financeiro',
    title: 'Analista Financeiro',
    level: 'Pleno',
    salary: 'R$ 7.000 - R$ 11.000',
    salaryMin: 7000,
    salaryMax: 11000,
    color: '#065F46',
    connections: ['coordenador-financeiro', 'controller'],
    pillar: 'Financeiro',
    description: 'Análise de demonstrações financeiras, orçamentos e indicadores econômicos.'
  },
  'coordenador-financeiro': {
    id: 'coordenador-financeiro',
    title: 'Coordenador Financeiro',
    level: 'Coordenação',
    salary: 'R$ 12.000 - R$ 18.000',
    salaryMin: 12000,
    salaryMax: 18000,
    color: '#047857',
    connections: ['gerente-financeiro'],
    pillar: 'Financeiro',
    description: 'Coordenação de processos financeiros e gestão de equipes.'
  },
  'controller': {
    id: 'controller',
    title: 'Controller',
    level: 'Sênior',
    salary: 'R$ 15.000 - R$ 22.000',
    salaryMin: 15000,
    salaryMax: 22000,
    color: '#059669',
    connections: ['gerente-financeiro'],
    pillar: 'Financeiro',
    description: 'Controle financeiro, auditoria interna e compliance fiscal.'
  },
  'gerente-financeiro': {
    id: 'gerente-financeiro',
    title: 'Gerente Financeiro',
    level: 'Gerência',
    salary: 'R$ 18.000 - R$ 28.000',
    salaryMin: 18000,
    salaryMax: 28000,
    color: '#10B981',
    connections: ['diretor-financeiro'],
    pillar: 'Financeiro',
    description: 'Gestão estratégica de finanças corporativas e planejamento orçamentário.'
  },
  'diretor-financeiro': {
    id: 'diretor-financeiro',
    title: 'Diretor Financeiro (CFO)',
    level: 'Diretoria',
    salary: 'R$ 25.000 - R$ 45.000',
    salaryMin: 25000,
    salaryMax: 45000,
    color: '#34D399',
    connections: [],
    pillar: 'Financeiro',
    description: 'Direção estratégica financeira da organização e relacionamento com investidores.'
  }
};